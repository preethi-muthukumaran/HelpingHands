const button = document.getElementById('submit');
button.addEventListener('click', async event =>{
  console.log("button pushed");
  const name = document.getElementById('name').value;
  const number = document.getElementById('number').value;
  const address = document.getElementById('address').value;
const service = document.getElementById('service').value;
const radius = document.getElementById('radius').value;
const comment = document.getElementById('comment').value;

  const data = {name,number,address,service,radius,comment};
  
  const options = {
    method: 'POST',
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  };
  const response = await fetch('/volunteer', options);
  const json = await response.json();
  console.log(json);
})